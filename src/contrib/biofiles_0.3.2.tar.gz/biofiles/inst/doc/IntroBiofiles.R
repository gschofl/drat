## ----style-knitr, eval=TRUE, echo=FALSE, results="asis"---------------------------------
BiocStyle::latex(width = 90)

## ----preliminaries----------------------------------------------------------------------
library(biofiles)

## ----mito-path,-------------------------------------------------------------------------
mito.path <- system.file("extdata", "S_cerevisiae_mito.gbk", package="biofiles")

## ----load-mita, echo=FALSE, eval=TRUE---------------------------------------------------
mito.rds <- system.file("extdata", "NC_001224.rds", package="biofiles")
mito <- loadRecord(mito.rds)

## ----read-mito, eval=FALSE, echo=TRUE---------------------------------------------------
#  mito <- gbRecord(mito.path)
#  mito

## ----display-mito, eval=TRUE, echo=FALSE------------------------------------------------
mito

## ----store-mito, eval=FALSE, echo=TRUE--------------------------------------------------
#  saveRecord(mito)
#  rm(mito)
#  mito <- loadRecord("NC_001224.rds")
#  summary(mito, n=3)

## ----display-store-mito, eval=TRUE, echo=FALSE------------------------------------------
summary(mito, n=3)

## ----summarise--------------------------------------------------------------------------
summary(mito)

## ----tabulate---------------------------------------------------------------------------
qualifTable(mito)
featureTable(mito)

## ----extract-header---------------------------------------------------------------------
getAccession(mito)
getDefinition(mito)
getGeneID(mito)
getOrganism(mito)
getLength(mito)
getComment(mito)

## ----extract-sequence-------------------------------------------------------------------
getSequence(mito)

## ----extract-ft-------------------------------------------------------------------------
ft(mito)

## ----extract-key------------------------------------------------------------------------
cds <- filter(mito, key = "CDS")
summary(cds[1:2])

## ----extact-key2------------------------------------------------------------------------
cds <- mito["CDS"]
summary(cds[3:4])

## ----extract-range----------------------------------------------------------------------
f10000 <- filter(mito, range = "..10000")
summary(f10000)

## ----extract-product--------------------------------------------------------------------
cytb <- filter(mito, key = "CDS", product = "^cytochrome b$")
cytb

## ----access-feature---------------------------------------------------------------------
start(cds[1:3])
end(cds[1:3])
span(cds[1:3])
strand(cds[1:3])
locusTag(cds[1:3])
dbxref(cds[1:3])
product(cds[1:3])
translation(cds[1:3])

## ----access-sequence--------------------------------------------------------------------
getSequence(cds[1:6])

## ----access-qualif----------------------------------------------------------------------
qualif(cds[1:3])
qualif(cds[1:3], which = c("gene", "locus_tag", "EC_number", "product", "db_xref.GeneID"))

## ----access-select----------------------------------------------------------------------
cols <- c("key", "gene", "locus_tag", "product")
select(cds[1:4], .cols = cols)

## ----granges----------------------------------------------------------------------------
ranges(cds)

## ----granges-more-----------------------------------------------------------------------
ranges(cds, join = TRUE, include = c("gene", "product", "db_xref"))

## ----sessinfo---------------------------------------------------------------------------
sessionInfo()

