library(testthat)
library(biofiles)
test_check("biofiles")