library(testthat)
test_check("blastr")